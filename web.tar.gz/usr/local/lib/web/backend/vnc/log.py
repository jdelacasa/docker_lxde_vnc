import logging
log = logging.getLogger('novnc2')
